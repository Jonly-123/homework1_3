import urllib.request as ur
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
import lxml.etree as le
import re


url='https://so.csdn.net/so/search/s.do?p={page}&q={keyword}_&t=blog&viparticle=&domain=&o=&s=&u=&l=&f=&rbg=0'
def GetResponse(url):
    request = ur.Request(
        url=url,
        headers={
            'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'
        }
    )
    response = ur.urlopen(request).read()
    return response



if __name__ == '__main__':
    keyword=input('关键词：')
    pn_start=int(input('开始页面：'))
    pn_end=int(input('截止页面：'))

    for page in (pn_start,pn_end+1):
        response=GetResponse(
            url='https://so.csdn.net/so/search/s.do?p={page}&q={keyword}_&t=blog&viparticle=&domain=&o=&s=&u=&l=&f=&rbg=0'.format(page=page,keyword=keyword)
        )
        href_s=le.HTML(response).xpath('//div[@class="search-list-con"]/dl//span[@class="mr16"]/../../dt/div/a[1]/@href')
        for href in href_s:
            response_blog=GetResponse(
                url=href,
            )
            title=le.HTML(response_blog).xpath('//div[@class="article-title-box"]/h1/text()')[0]
            title = re.sub(r'[:<>./\\|"*?]', '', title)

            filepath ='blog/%s.html' % title

            with open(filepath,'wb') as f:
                f.write(response_blog)
            print(title)
