import urllib.parse as up
import urllib.request as ur
import json
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

word=input('请输入要翻译的文字：')

data={
    'kw':word
}
# 编码
data_url=up.urlencode(data)
print(data_url)
print(data_url.encode('utf-8'))

request=ur.Request(
    url='https://fanyi.baidu.com/sug',
    data=data_url.encode('utf-8')
)

response=ur.urlopen(request).read()
# print(response)
ret = json.loads(response)
print(ret['data'][0]['v'])