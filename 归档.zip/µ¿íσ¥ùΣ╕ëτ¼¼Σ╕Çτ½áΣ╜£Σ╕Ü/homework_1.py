import lxml.etree as le

with open('edu.html','r',encoding='utf-8') as f:
    html=f.read()
    div_x_s=le.HTML(html).xpath('//div[contains(@class,"classify_cList")]')
    data_s=[]
    for div_x in div_x_s:
        category_1=div_x.xpath('./h3/a/text()')[0]
        category_2_s=div_x.xpath('./div/span/a/text()')
        data_s.append(
            {
                'category_1': category_1,
                'category_2_s': category_2_s,
            }
        )
        for data in data_s:
            print(data['category_1'])
            for category_2 in data['category_2_s']:
                print('    ',category_2)
