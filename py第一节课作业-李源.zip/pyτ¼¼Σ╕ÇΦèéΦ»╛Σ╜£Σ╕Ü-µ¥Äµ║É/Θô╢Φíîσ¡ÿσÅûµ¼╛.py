# 设立银行账户
card1='10001'
password1='12345'
banlance1=1000

card2='10002'
password2='22345'
banlance2=10000

#
while 1==1:
    print('='*20,'欢迎来到py银行','='*20)
    card = input('请输入您的卡号：')
    password = input('请输入您的密码：')

    ban = 0
    if card == card1 and password == password1:
        ban = banlance1

    elif card == card2 and password == password2:
        ban = banlance2

    else:
        times = times + 1    
        if times >=3: # 判断输入3次，冻结银行卡
            print('您已经3次输入错误，银行卡已被冻结')
        else: 
            print('卡号密码输入错误，请重新输入')
            continue

    while 1==1:
        print('{:1} {:13} {:15}'.format('  ','1.查询余额','2.存款'))
        print('{:1} {:13} {:15}'.format('  ','3.点击取款','4.退出'))
        num = input('请输入对应选择:')
        
        #  对输入选择做判断
        if num == '1':
            print(ban)
        elif num == '2':
            inn = float(input('请输入存款金额：'))
            if inn <= 0:
                print('输入有误')
            else:
                ban=ban+inn
                print('存款成功，存入金额：',inn,'余额：',ban)

        elif num== '3':
            out = float(input('请输入取款金额：'))
            if out > ban:
                print('余额不足')
            else:
                ban=ban-out
                print('取款成功，取入金额：',out,'余额：',ban)
           
        elif num == '4':
            print('欢迎使用，请取走您的卡片')

            
        else:
            print(' 输入有误！请重新输入！')






