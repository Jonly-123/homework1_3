
import os


def getFileSize(filePath,size = 0): # 定义获取文件大小的函数，初始文件大小是0

    for root, dirs, files in os.walk(filePath): 

        for f in files:

            size += os.path.getsize(os.path.join(root, f))

            print(f)

    return size

print(getFileSize('./yuanleetest'))